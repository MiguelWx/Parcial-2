package parcialclase.Interface;

import java.util.List;

public interface IEncriptacion{

    boolean IntercambiarNodos();
    void DecifradoLetraNodo();
   void incrementaImpar();
   void DesencriptarImpar();
   void DecifrarFrase();
    
}