package parcialclase.Model;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import parcialclase.Util.ListaEnlazada;
import parcialclase.Util.PerformanceMonitor;
import parcialclase.Interface.IEncriptacion;

public class Frase implements IEncriptacion {

    

    private static final Logger logger = LogManager.getLogger(Frase.class.getName());
    private static final Logger loggerTiempos = LogManager.getLogger("tiempos");

    private String q;

    public String getQ() {
        return q;
    }

    public void setQ(String q) {
        this.q = q;
    }

    private Deque<String> fraseSeparadas = new ArrayDeque<>();
    private Deque<String> charsX = new ArrayDeque<>();
    private Deque<String> valorAscii = new ArrayDeque<>();
    private Deque<String> fraseFinal = new ArrayDeque<>();

    public void procesarFrases() {
        long inicio = System.nanoTime();
        logger.info("Iniciando procesamiento de frases...");
        logger.info("Procesando frase: {}", q);

        Deque<String> nuevaLista = new ArrayDeque<>();
        fraseSeparadas.clear();
        charsX.clear();
        valorAscii.clear();
        fraseFinal.clear();

        String[] palabras = q.split(" ");
        for (String palabra : palabras) {
            fraseSeparadas.add(palabra);
            logger.info("Palabra encontrada: {}", palabra);
            for (char c : palabra.toCharArray()) {
                charsX.add(String.valueOf(c));
                logger.info("Caracter añadido: {}", c);
            }
        }

        for (String palabra : fraseSeparadas) {
            for (char ch : palabra.toCharArray()) {
                int ascii = (int) ch;
                nuevaLista.add(ascii + "");
                logger.info("Convertido '{}' a ASCII: {}", ch, ascii);
            }
        }

        valorAscii = nuevaLista;

        long fin = System.nanoTime();
        double ms = (fin - inicio) / 1_000_000.0;
        loggerTiempos.info("procesarFrases completado en {} ms", ms);
    }

    @Override
    public void incrementaImpar() {
        long inicio = System.nanoTime();
        logger.info("Iniciando incremento impar...");

        Deque<String> nuevaLista = new ArrayDeque<>();
        for (String palabra : fraseSeparadas) {
            int incremento = 1;
            for (char ch : palabra.toCharArray()) {
                int ascii = (int) ch + incremento;
                nuevaLista.add(ascii + "");
                logger.info("Caracter '{}' incrementado en {} → {}", ch, incremento, ascii);
                incremento += 2;
            }
        }

        valorAscii = nuevaLista;

        long fin = System.nanoTime();
        double ms = (fin - inicio) / 1_000_000.0;
        loggerTiempos.info("incrementaImpar completado en {} ms", ms);
    }

    @Override
    public void DesencriptarImpar() {
        long inicio = System.nanoTime();
        logger.info("Iniciando desencriptación impar...");

        Deque<String> nuevaLista = new ArrayDeque<>();
        Deque<String> valoresEncriptados = new ArrayDeque<>(valorAscii);

        for (String palabra : fraseSeparadas) {
            int incremento = 1;
            for (int i = 0; i < palabra.length(); i++) {
                if (valoresEncriptados.isEmpty()) {
                    logger.warn("Valores encriptados vacíos, deteniendo proceso.");
                    break;
                }
                String asciiStr = valoresEncriptados.poll();
                int asciiEncriptado = Integer.parseInt(asciiStr);
                char letraOriginal = (char) (asciiEncriptado - incremento);
                nuevaLista.add((int) letraOriginal + "");
                logger.info("Restaurado: {}", (int) letraOriginal);
                incremento += 2;
            }
        }

        valorAscii = nuevaLista;

        long fin = System.nanoTime();
        double ms = (fin - inicio) / 1_000_000.0;
        loggerTiempos.info("DesencriptarImpar completado en {} ms", ms);
    }


    @Override
    public boolean IntercambiarNodos() {
        long inicio = System.nanoTime();
        logger.info("Iniciando intercambio de nodos...");

        if (valorAscii == null || valorAscii.isEmpty()) {
            logger.error("valorAscii vacío, no se pueden intercambiar nodos.");
            return false;
        }

        ListaEnlazada lista = new ListaEnlazada();
        for (String valor : valorAscii) {
            lista.agregar(valor);
        }

        lista.intercambiarNodosAdyacentes();
        List<String> intercambiados = lista.toList();

        valorAscii.clear();
        for (String valor : intercambiados) {
            valorAscii.add(valor);
            logger.info("Nodo intercambiado: {}", valor);
        }

        long fin = System.nanoTime();
        double ms = (fin - inicio) / 1_000_000.0;
        loggerTiempos.info("IntercambiarNodos completado en {} ms", ms);
        return true;
    }

    @Override
    public void DecifradoLetraNodo() {
        long inicio = System.nanoTime();
        logger.info("Iniciando decifrado de letra...");

        if (valorAscii == null || valorAscii.isEmpty()) {
            logger.warn("valorAscii vacío, no se puede decifrar.");
            return;
        }

        ListaEnlazada lista = new ListaEnlazada();
        for (String valor : valorAscii) {
            lista.agregar(valor);
        }

        lista.intercambiarNodosAdyacentes();
        List<String> restaurado = lista.toList();

        valorAscii.clear();
        for (String valor : restaurado) {
            valorAscii.add(valor);
            logger.info("Restaurado: {}", valor);
        }

        long fin = System.nanoTime();
        double ms = (fin - inicio) / 1_000_000.0;
        loggerTiempos.info("DecifradoLetra completado en {} ms", ms);
    }

@Override
public void DecifrarFrase() {
    long inicio = System.nanoTime();
    logger.info("Iniciando proceso de decifrado de frase...");
    logger.debug("Contenido inicial de valorAscii: {}", valorAscii);

    String frase = ""; 

    int indice = 0;
    for (String asciiStr : valorAscii) {
        try {
            logger.info("Procesando índice [{}] con valor: {}", indice, asciiStr);

            int ascii = Integer.parseInt(asciiStr);
            char letra = (char) ascii;
            frase += letra; 

            logger.info("Convertido a char '{}' (ASCII: {})", letra, ascii);
        } catch (NumberFormatException e) {
            logger.error("Error convirtiendo a ASCII en índice [{}], valor inválido: {}", indice, asciiStr, e);
        }
        indice++;
    }

    fraseFinal.clear();
    fraseFinal.add(frase);
    logger.info("Frase reconstruida exitosamente: '{}'", frase);

    long fin = System.nanoTime();
    double ms = (fin - inicio) / 1_000_000.0;
    loggerTiempos.info("DecifrarFrase completado en {} ms", ms);
}

public Deque<String> getFraseFinal() {
    return fraseFinal;
}


    @Override
    public String toString() {
        return ("Frases: " + q + "\n Frases separadas: " + fraseSeparadas
                + "\n Caracteres: " + charsX
                + "\n valoresAscii: " + valorAscii
                + "\n Frase descifrada:" + fraseFinal);
    }
}

