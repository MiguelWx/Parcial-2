package parcialclase;

import parcialclase.Model.Frase;
import parcialclase.Service.ApiService;
import parcialclase.Util.PerformanceMonitor;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class App {

    private static final Logger loggerTiempos = LogManager.getLogger("tiempos");
    private static final Logger logger = LogManager.getLogger("main");
    public static void main(String[] args) {

         PerformanceMonitor performanceMonitor = new PerformanceMonitor("Frases");
         PerformanceMonitor performanceTamano = new PerformanceMonitor("Frases-tamaños");
         performanceMonitor.inicio();

          ApiService api = new ApiService();

            List<Frase> frases = api.getFrases();

        for (Frase f : frases) {
            f.procesarFrases();
            f.incrementaImpar();
            f.IntercambiarNodos();
            f.DecifradoLetraNodo();
            f.DesencriptarImpar();
            f.DecifrarFrase();
            logger.info("Frase del API procesada: {}", f.getFraseFinal());
        }


        performanceMonitor.finalizado(); 
          

         performanceTamano.inicio(); 
        int[] tamaños = {10, 50, 100, 200, 400, 800, 1000, 3000, 5000, 10000};

        
        for (int tamaño : tamaños) {

            String fraseGenerada = generarFrase(tamaño);

            Frase frase = new Frase();
            frase.setQ(fraseGenerada);

           
            long startEncriptado = System.nanoTime();
            frase.procesarFrases();
            frase.incrementaImpar();
            frase.IntercambiarNodos();
            long endEncriptado = System.nanoTime();

            long startDesencriptado = System.nanoTime();
            frase.DecifradoLetraNodo();
            frase.DesencriptarImpar();
            frase.DecifrarFrase();
            long endDesencriptado = System.nanoTime();

            double tiempoEncriptado = (endEncriptado - startEncriptado) / 1_000_000.0;
            double tiempoDesencriptado = (endDesencriptado - startDesencriptado) / 1_000_000.0;
            double tiempoTotal = tiempoEncriptado + tiempoDesencriptado;

            loggerTiempos.info("{}, {}, {}, {}", tamaño, tiempoEncriptado, tiempoDesencriptado, tiempoTotal);
        }

        performanceTamano.finalizado(); 
    }

    public static String generarFrase(int longitud) {
        String frase = "";
        for (int i = 0; i < longitud; i++) {
            char c = (char) ('A' + (i % 26));
            frase += c;
            if (i % 5 == 4) frase += " ";
        }
        return frase.trim();
    }
}
